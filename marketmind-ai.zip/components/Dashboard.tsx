import React from 'react';
import { AnalysisResult } from '../types';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

interface DashboardProps {
  data: AnalysisResult;
}

export const Dashboard: React.FC<DashboardProps> = ({ data }) => {
  const isPositive = data.stock.change >= 0;
  const sentimentColor = data.sentimentScore > 60 ? 'text-green-400' : data.sentimentScore < 40 ? 'text-red-400' : 'text-yellow-400';
  const sentimentBg = data.sentimentScore > 60 ? 'bg-green-500' : data.sentimentScore < 40 ? 'bg-red-500' : 'bg-yellow-500';

  return (
    <div className="animate-fade-in pb-20">
      {/* Header Info Card */}
      <div className="glass rounded-2xl p-8 mb-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">{data.stock.symbol}</h1>
            <p className="text-gray-400 text-lg">{data.stock.name}</p>
          </div>
          <div className="text-right">
            <div className="text-5xl font-bold text-white mb-2">
              {data.stock.currency === 'USD' ? '$' : ''}{data.stock.price.toLocaleString()}
            </div>
            <div className={`text-xl font-medium flex items-center justify-end gap-2 ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
              {isPositive ? (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" /></svg>
              )}
              {data.stock.change > 0 ? '+' : ''}{data.stock.change} ({data.stock.changePercent}%)
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 glass rounded-2xl p-6 min-h-[400px]">
          <h3 className="text-xl font-semibold text-white mb-6">Price Trend (30 Days)</h3>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data.historicalData}>
                <defs>
                  <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={isPositive ? "#10B981" : "#EF4444"} stopOpacity={0.3}/>
                    <stop offset="95%" stopColor={isPositive ? "#10B981" : "#EF4444"} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  stroke="#9CA3AF" 
                  tick={{fontSize: 12}}
                  tickFormatter={(val) => new Date(val).getDate().toString()} 
                />
                <YAxis 
                  stroke="#9CA3AF" 
                  tick={{fontSize: 12}}
                  domain={['auto', 'auto']}
                  tickFormatter={(val) => `$${val}`}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1F2937', borderColor: '#374151', color: '#F3F4F6' }}
                  itemStyle={{ color: '#F3F4F6' }}
                  labelStyle={{ color: '#9CA3AF' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="price" 
                  stroke={isPositive ? "#10B981" : "#EF4444"} 
                  fillOpacity={1} 
                  fill="url(#colorPrice)" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Sentiment Card */}
        <div className="glass rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-xl font-semibold text-white mb-4">AI Sentiment Score</h3>
            <div className="relative pt-4 pb-8 flex justify-center">
                <div className="relative w-48 h-24 overflow-hidden">
                    <div className="absolute top-0 left-0 w-full h-full bg-gray-700 rounded-t-full"></div>
                    <div 
                        className={`absolute top-0 left-0 w-full h-full rounded-t-full origin-bottom transition-transform duration-1000 ease-out ${sentimentBg}`}
                        style={{ transform: `rotate(${(data.sentimentScore / 100) * 180 - 180}deg)` }}
                    ></div>
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-40 h-4 bg-gray-900 rounded-full z-10"></div>
                </div>
                <div className="absolute bottom-0 text-center">
                    <span className={`text-5xl font-bold ${sentimentColor}`}>{data.sentimentScore}</span>
                    <span className="text-gray-400 text-sm block mt-1">/ 100</span>
                </div>
            </div>
            <p className="text-gray-300 text-sm mt-6 leading-relaxed">
              {data.sentimentReasoning}
            </p>
          </div>
        </div>

        {/* Analysis Summary */}
        <div className="lg:col-span-2 glass rounded-2xl p-6">
          <h3 className="text-xl font-semibold text-white mb-4">Executive Summary</h3>
          <p className="text-gray-300 leading-relaxed text-lg">
            {data.summary}
          </p>
        </div>

        {/* Pros & Cons */}
        <div className="glass rounded-2xl p-6">
           <h3 className="text-xl font-semibold text-white mb-4">Analysis</h3>
           <div className="space-y-6">
             <div>
               <h4 className="text-green-400 font-medium mb-3 flex items-center gap-2">
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                 Bullish Signals
               </h4>
               <ul className="space-y-2">
                 {data.pros.map((pro, i) => (
                   <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                     <span className="w-1.5 h-1.5 bg-green-500 rounded-full mt-1.5 shrink-0"></span>
                     {pro}
                   </li>
                 ))}
               </ul>
             </div>
             <div>
               <h4 className="text-red-400 font-medium mb-3 flex items-center gap-2">
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                 Bearish Risks
               </h4>
               <ul className="space-y-2">
                 {data.cons.map((con, i) => (
                   <li key={i} className="text-gray-300 text-sm flex items-start gap-2">
                     <span className="w-1.5 h-1.5 bg-red-500 rounded-full mt-1.5 shrink-0"></span>
                     {con}
                   </li>
                 ))}
               </ul>
             </div>
           </div>
        </div>
      </div>
        
      {/* Sources */}
      {data.sources && data.sources.length > 0 && (
        <div className="mt-8">
            <h4 className="text-gray-500 text-sm uppercase tracking-wider font-semibold mb-4">Verified Sources</h4>
            <div className="flex flex-wrap gap-3">
                {data.sources.map((source, i) => (
                    <a 
                        key={i} 
                        href={source.uri} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="flex items-center gap-2 px-4 py-2 bg-gray-800 hover:bg-gray-700 border border-gray-700 rounded-lg text-xs text-blue-400 transition-colors"
                    >
                        <span className="truncate max-w-[200px]">{source.title}</span>
                        <svg className="w-3 h-3 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                    </a>
                ))}
            </div>
        </div>
      )}
    </div>
  );
};
