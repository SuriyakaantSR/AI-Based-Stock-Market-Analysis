export interface HistoricalPoint {
  date: string;
  price: number;
}

export interface StockData {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  currency: string;
  marketTime: string;
}

export interface AnalysisResult {
  stock: StockData;
  summary: string;
  sentimentScore: number; // 0 to 100
  sentimentReasoning: string;
  pros: string[];
  cons: string[];
  historicalData: HistoricalPoint[];
  sources: { title: string; uri: string }[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}
