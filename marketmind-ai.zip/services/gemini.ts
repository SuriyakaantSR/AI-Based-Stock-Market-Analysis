import { GoogleGenAI, Type, Schema } from "@google/genai";
import { AnalysisResult } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const analysisSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    symbol: { type: Type.STRING, description: "Stock ticker symbol (e.g., AAPL)" },
    name: { type: Type.STRING, description: "Full company name" },
    price: { type: Type.NUMBER, description: "Current stock price" },
    change: { type: Type.NUMBER, description: "Price change value" },
    changePercent: { type: Type.NUMBER, description: "Price change percentage" },
    currency: { type: Type.STRING, description: "Currency code (e.g., USD)" },
    marketTime: { type: Type.STRING, description: "Time of the market data" },
    summary: { type: Type.STRING, description: "A concise executive summary of the stock's recent performance and news." },
    sentimentScore: { type: Type.NUMBER, description: "0-100 score where 0 is extremely bearish and 100 is extremely bullish." },
    sentimentReasoning: { type: Type.STRING, description: "Explanation for the sentiment score." },
    pros: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of positive factors or bullish signals."
    },
    cons: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of negative factors or bearish risks."
    },
    historicalData: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          date: { type: Type.STRING, description: "YYYY-MM-DD" },
          price: { type: Type.NUMBER }
        }
      },
      description: "Estimated or actual closing prices for the last 30 days to plot a chart."
    }
  },
  required: ["symbol", "name", "price", "change", "changePercent", "summary", "sentimentScore", "pros", "cons", "historicalData"]
};

export const analyzeStock = async (query: string): Promise<AnalysisResult> => {
  try {
    const prompt = `
      Analyze the stock market status for: "${query}".
      
      1. Use Google Search to find the REAL-TIME price, today's change, and the latest news/events affecting this stock.
      2. Synthesize this information into a structured JSON response.
      3. Provide a sentiment score (0-100) based on the news.
      4. List key pros and cons for investors.
      5. Generate a dataset of the last 30 days of closing prices. If exact historical data is not directly available in the search snippet, generate a realistic trend based on the known 1-month performance (e.g., if it's up 5%, show a trend upwards).
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: analysisSchema,
        systemInstruction: "You are an expert financial analyst. Always provide accurate, real-time data where possible. Be objective but decisive.",
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");

    const data = JSON.parse(text);
    
    // Extract sources from grounding metadata if available
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.filter((chunk: any) => chunk.web?.uri && chunk.web?.title)
      .map((chunk: any) => ({
        title: chunk.web.title,
        uri: chunk.web.uri
      })) || [];

    // Remove duplicates from sources
    const uniqueSources = Array.from(new Map(sources.map((s: any) => [s.uri, s])).values()) as { title: string; uri: string }[];

    return {
      stock: {
        symbol: data.symbol,
        name: data.name,
        price: data.price,
        change: data.change,
        changePercent: data.changePercent,
        currency: data.currency || "USD",
        marketTime: data.marketTime || new Date().toISOString()
      },
      summary: data.summary,
      sentimentScore: data.sentimentScore,
      sentimentReasoning: data.sentimentReasoning,
      pros: data.pros,
      cons: data.cons,
      historicalData: data.historicalData,
      sources: uniqueSources
    };

  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    throw error;
  }
};
